const pai2 = document.querySelector(".pai2")
const nome = ["Capivara", "Pato", "Coelho", "Kuromi", "Cat noir", "Hello Kitty"];
const imagem = ["Pelucia 1.PNG", "Pelucia 2.PNG", "Pelucia 3.PNG", "Pelucia 4.PNG", "Pelucia 5.PNG", "Pelucia 6.PNG"];
const preco = ["100", "130", "89", "120", "2000", "150"];

for ( let i=0; i<nome.length; i++) { 
    pai2.innerHTML +=
    `<div class="pelucia"> 
        <img class="imgs"src = "${imagem[i]}">
         <p> Oferta do dia </p>
         <p> ${nome[i]} </p>
         <p> ${preco[i]} </p>
        <div> <p> Chegará grátis amanhã </p>
        <img src = "Imagens/Imagens/full.png"
        </div>
    </div>` 
}